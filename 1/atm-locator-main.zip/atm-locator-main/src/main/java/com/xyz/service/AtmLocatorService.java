package com.xyz.service;

import org.springframework.stereotype.Service;

@Service
public class AtmLocatorService {

    public String locateAtms() {
        return "Hello";
    }
}
